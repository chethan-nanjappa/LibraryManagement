Springboot Microservice Gradle Project
*******************************************************************************

#application runs on the port 9090
-- Run the LibraryManagementApplication class to launch the application.

Rest End Points 

1) View Books
localhost:9090/viewBooks

2) Borrow Book
localhost:9090/borrowBook/{bookId}/{userId}

4) Borrow copy of Book
localhost:9090/borrowCopyOfBook/{bookId}/{userId}

5) Return Book
localhost:9090/returnBook/{bookId}/{userId}

The application has two models User and Book.

--User have three records with id and corresponding book object 
--Book has three books with Id name and book count currently available in the Library.

Test Cases.

--I have written TestNg test cases for Service class and it covers upto 96% code coverage.