package com.chethan.library.model;

import java.util.ArrayList;
import java.util.Objects;

public class User {

    Integer id;
    ArrayList<Book> bookList;

    public User() {
    }

    public User(Integer id, ArrayList<Book> bookList) {
        this.id = id;
        this.bookList = bookList;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public ArrayList<Book> getBookList() {
        return bookList;
    }

    public void setBookList(ArrayList<Book> bookList) {
        this.bookList = bookList;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        User user = (User) o;
        return id.equals(user.id) && bookList.equals(user.bookList);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, bookList);
    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", bookList=" + bookList +
                '}';
    }
}
