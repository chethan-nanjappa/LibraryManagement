package com.chethan.library.controller;

import java.util.ArrayList;
import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.chethan.library.model.Book;
import com.chethan.library.model.User;
import com.chethan.library.service.LibraryService;

@RestController
public class LibraryController {

	@Autowired
	private LibraryService libraryService;
	String message = null;

	@RequestMapping(path = "/viewBooks")
	public Object viewBook() {
		ArrayList<Book> viewBooks = libraryService.viewBook();
		if (viewBooks.size() != 0)
			return "Available books in the Library:  " + viewBooks;
		return "There are no books in the Library";

	}

	@RequestMapping(value = "/borrowBook/{bookId}/{userId}")
	public Object borrowBook(@PathVariable("bookId") int bookId, @PathVariable("userId") int userId) {
		User bookBorrowed;
		if (libraryService.validateParama(bookId, userId)) {
			try {
				bookBorrowed = libraryService.borrowBook(bookId, userId);
				return "Successfully borrowed the Book :     " + bookBorrowed;
			} catch (Exception e) {
				message = e.getMessage();
			}
		} else {
			message = "Invalid book / user id";
		}
		return message;
	}

	@RequestMapping(value = "/borrowCopyOfBook/{bookId}/{userId}")
	public Object borrowCopyOfBook(@PathVariable("bookId") int bookId, @PathVariable("userId") int userId) {
		User copyOfbookBorrowed;
		if (libraryService.validateParama(bookId, userId)) {
			try {
				copyOfbookBorrowed = libraryService.borrowCopyOfBook(bookId, userId);
				return "Successfully borrowed copy of the Book:  " + copyOfbookBorrowed;
			} catch (Exception e) {
				message = e.getMessage();
			}
		} else {
			message = "Invalid book / user id";
		}
		return message;
	}

	@RequestMapping(value = "/returnBook/{bookId}/{userId}")
	public Object returnBook(@PathVariable("bookId") int bookId, @PathVariable("userId") int userId) {
		if (libraryService.validateParama(bookId, userId)) {
			try {
				User bookReturn = libraryService.returnBook(bookId, userId);
				return "Successfully returned copy of the Book:  " + bookReturn;
			} catch (Exception e) {
				message = e.getMessage();
			}
		} else {
			message = "Invalid book / user id";
		}
		return message;
	}

}
