package com.chethan.library.serviceImpl;

import com.chethan.library.model.Book;
import com.chethan.library.model.User;
import com.chethan.library.service.LibraryService;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

@Service
public class LibraryServiceImpl implements LibraryService {

	// Assume library has 2 copies of 3 different books
	Map<Integer, Book> bookMap = new HashMap<>();

	// Assume library has 3 subscribers / users
	Map<Integer, User> userMap = new HashMap<>();

	public LibraryServiceImpl(){

		bookMap.put(1, new Book(1, "A", 2));
		bookMap.put(2, new Book(2, "B", 2));
		bookMap.put(3, new Book(3, "C", 2));

		userMap.put(1, new User(1, null));
		userMap.put(2, new User(2, null));
		userMap.put(3, new User(3, null));

	}



	@Override
	public ArrayList<Book> viewBook() {
		return  new ArrayList<>(bookMap.values());
	}

	@Override
	public ArrayList<User> borrowBook(Integer bookId, Integer userId) throws Exception {

		// Use below 2 lines in Controller
		Book book = bookMap.getOrDefault(bookId, null);
		User user = userMap.getOrDefault(userId, null);

		// Use below lines in Service
		if(book == null || book.getBookCount() <=0 || user == null)
			throw new Exception("Invalid book / user id");

		ArrayList<Book> userBookList = user.getBookList();
		if (userBookList == null)
			userBookList = new ArrayList<>();

		if (userBookList.contains(book.getId()))
			throw new Exception("Only 1 copy of a book can be borrowed by a User at any point of time");

		userBookList.add(book);
		user.setBookList(userBookList);

		book.setBookCount(book.getBookCount() - 1);

		// Handle exception in Controller
		return new ArrayList<>(userMap.values());

	}

	@Override
	public ArrayList<User> borrowCopyOfBook(Integer bookId, Integer userId) throws Exception {
		return borrowBook(bookId, userId);
	}

	@Override
	public ArrayList<User> returnBook(Integer bookId, Integer userId) throws Exception {

		// Use below 2 lines in Controller
		Book book = bookMap.getOrDefault(bookId, null);
		User user = userMap.getOrDefault(userId, null);

		// Use below lines in Service
		if(book == null || book.getBookCount() <=0 || user == null)
			throw new Exception("Invalid book / user id");

		ArrayList<Book> userBookList = user.getBookList();
		userBookList.removeIf( obj -> obj.getId() == bookId);

		book.setBookCount(book.getBookCount() + 1);

		// Handle exception in Controller
		return new ArrayList<>(userMap.values());

	}

	public static void main(String[] args) throws Exception {

		// Initialize variables
		Integer bookId=1, userId=1;
		LibraryServiceImpl lsi = new LibraryServiceImpl();

		//	1. User can view books in library
		System.out.println("Books available in library");
		System.out.println(lsi.viewBook());

		//	2 | 3. User can borrow book from library
		System.out.println("Borrow book from library");
		System.out.println(lsi.borrowBook(bookId, userId));
		System.out.println(lsi.borrowBook(bookId=2, userId=1));

		// 4. User can return to library
		System.out.println("Return book to library");
		System.out.println(lsi.returnBook(bookId, userId));

		// View books in library
		System.out.println("Books available in library");
		System.out.println(lsi.viewBook());

	}

}
