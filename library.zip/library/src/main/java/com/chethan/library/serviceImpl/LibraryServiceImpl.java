package com.chethan.library.serviceImpl;

import com.chethan.library.model.Book;
import com.chethan.library.model.User;
import com.chethan.library.service.LibraryService;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

@Service
public class LibraryServiceImpl implements LibraryService {

	// Assume library has 2 copies of 3 different books
	Map<Integer, Book> bookMap = new HashMap<>();

	// Assume library has 3 users
	Map<Integer, User> userMap = new HashMap<>();
	boolean validBook = false;
	boolean validUser = false;
	boolean availableBooks = false;

	public LibraryServiceImpl() {

		bookMap.put(1, new Book(1, "A", 2));
		bookMap.put(2, new Book(2, "B", 2));
		bookMap.put(3, new Book(3, "C", 2));

		userMap.put(1, new User(1, null));
		userMap.put(2, new User(2, null));
		userMap.put(3, new User(3, null));
	}

	@Override
	public ArrayList<Book> viewBook() {
		if (getAvailableBooks())
			return new ArrayList<>(bookMap.values());
		else
			return null;
	}

	@Override
	public User borrowBook(Integer bookId, Integer userId) throws Exception {

		Book book = bookMap.getOrDefault(bookId, null);
		User user = userMap.getOrDefault(userId, null);

		if (book == null || book.getBookCount() <= 0 || user == null)
			throw new Exception("Invalid book / user id");

		ArrayList<Book> userBookList = user.getBookList();
		if (userBookList == null)
			userBookList = new ArrayList<>();

		for (int i = 0; i < userBookList.size(); i++){
			if (userBookList.get(i).getId() == book.getId())
				throw new Exception("Only 1 copy of a book can be borrowed by a User at any point of time");
			else if (userBookList.size() >= 2)
				throw new Exception("Each user has a borrowing limit of 2 books at any point of time");
		}
		
		userBookList.add(book);
		user.setBookList(userBookList);
		book.setBookCount(book.getBookCount() - 1);
		return user;
	}

	@Override
	public User borrowCopyOfBook(Integer bookId, Integer userId) throws Exception {
		return borrowBook(bookId, userId);
	}

	@Override
	public User returnBook(Integer bookId, Integer userId) throws Exception {

		Book book = bookMap.getOrDefault(bookId, null);
		User user = userMap.getOrDefault(userId, null);

		if (null == user)
			throw new Exception("The user does not exist ");
		if (!userMap.containsKey(userId) || null == user.getBookList())
			throw new Exception("The user does not have book to retutn ");

		ArrayList<Book> userBookList = user.getBookList();
		userBookList.removeIf(obj -> obj.getId() == bookId);
		book.setBookCount(book.getBookCount() + 1);
		return user;
	}

	@Override
	public boolean validateParama(int bookId, int userId) {
		validBook = (null != Integer.valueOf(bookId) && bookMap.containsKey(bookId)) ? true : false;
		validUser = (null != Integer.valueOf(userId) && userMap.containsKey(userId)) ? true : false;

		if (validBook && validUser)
			return true;
		else
			return false;
	}

	private boolean getAvailableBooks() {
		int counter = 0;
		for (Entry<Integer, Book> entry : bookMap.entrySet())
			counter = counter + entry.getValue().getBookCount();
		availableBooks = counter > 0 ? true : false;
		return availableBooks;
	}
}
