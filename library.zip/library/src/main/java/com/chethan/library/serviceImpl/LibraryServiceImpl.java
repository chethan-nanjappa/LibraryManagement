package com.chethan.library.serviceImpl;

import java.util.ArrayList;

import org.springframework.stereotype.Service;

import com.chethan.library.model.Book;
import com.chethan.library.service.LibraryService;

@Service
public class LibraryServiceImpl implements LibraryService {

	@Override
	public Book viewBook() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Book borrowBook() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Book borrowCopyOfBook() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void returnBook(ArrayList<Book> book) {
		// TODO Auto-generated method stub		
	}

}
