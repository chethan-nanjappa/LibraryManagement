package com.chethan.library.model;

public class Book {

}
