package com.chethan.library.model;

import java.util.Objects;

public class Book {

    Integer id;
    String bookName;
    Integer bookCount;

    public Book() {
    }

    public Book(Integer id, String bookName, Integer bookCount) {
        this.id = id;
        this.bookName = bookName;
        this.bookCount = bookCount;
    }


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getBookName() {
        return bookName;
    }

    public void setBookName(String bookName) {
        this.bookName = bookName;
    }

    public Integer getBookCount() {
        return bookCount;
    }

    public void setBookCount(Integer bookCount) {
        this.bookCount = bookCount;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Book book = (Book) o;
        return id.equals(book.id) && bookName.equals(book.bookName) && bookCount.equals(book.bookCount);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, bookName, bookCount);
    }

    @Override
    public String toString() {
        return "Book{" +
                "id=" + id +
                ", bookName='" + bookName + '\'' +
                ", bookCount=" + bookCount +
                '}';
    }
}
