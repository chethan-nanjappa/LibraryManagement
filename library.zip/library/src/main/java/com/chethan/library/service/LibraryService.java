package com.chethan.library.service;

import java.util.ArrayList;

import org.springframework.stereotype.Service;

import com.chethan.library.model.Book;

@Service
public interface LibraryService {
	public Book viewBook();
	public Book borrowBook();
	public Book borrowCopyOfBook();
	public void returnBook(ArrayList<Book> book);
}
