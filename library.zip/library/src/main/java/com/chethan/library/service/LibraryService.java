package com.chethan.library.service;

import java.util.ArrayList;
import java.util.LinkedList;

import com.chethan.library.model.User;
import org.springframework.stereotype.Service;

import com.chethan.library.model.Book;

@Service
public interface LibraryService {

	public ArrayList viewBook();

	public ArrayList<User> borrowBook(Integer bookId, Integer userId) throws Exception;

	public ArrayList<User> borrowCopyOfBook(Integer bookId, Integer userId) throws Exception;

	public ArrayList<User> returnBook(Integer bookId, Integer userId) throws Exception;

}
