package com.chethan.library.serviceImpl;

import java.util.ArrayList;

import org.mockito.InjectMocks;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.chethan.library.model.Book;
import com.chethan.library.model.User;

public class LibraryServiceImplTest {
	private @InjectMocks LibraryServiceImpl libraryServiceImpl = new LibraryServiceImpl();

	@Test
	public void viewBook_test() {
		ArrayList<Book> reply = new ArrayList<>();
		reply = libraryServiceImpl.viewBook();
		Assert.assertEquals(reply.get(0).getBookName(), "A");
		Assert.assertNotNull(reply);
	}

	@Test
	public void borrowBook_success() throws Exception {
		User reply = new User();
		reply = libraryServiceImpl.borrowBook(1, 1);
		Assert.assertNotNull(reply);
		Assert.assertEquals(reply.getBookList().get(0).getId(), Integer.valueOf(1));
		Assert.assertEquals(reply.getId(), Integer.valueOf(1));
	}

	@Test
	public void borrowBook_failure_invalidBook() throws Exception {
		Object reply = new Object();
		try {
			reply = libraryServiceImpl.borrowBook(5, 1);
		} catch (Exception e) {
			reply = e.getMessage();
		}
		Assert.assertNotNull(reply);
		Assert.assertEquals(reply, "Invalid book / user id");
	}

	@Test
	public void borrowBook_failure_duplicateBook() throws Exception {
		Object reply = new Object();
		libraryServiceImpl.borrowBook(2, 3);
		try {
			reply = libraryServiceImpl.borrowBook(2, 3);
		} catch (Exception e) {
			reply = e.getMessage();
		}
		Assert.assertNotNull(reply);
		Assert.assertEquals(reply, "Only 1 copy of a book can be borrowed by a User at any point of time");
	}

	@Test
	public void borrowCopyOfBook_success() throws Exception {
		User reply = new User();
		reply = libraryServiceImpl.borrowCopyOfBook(2, 2);
		Assert.assertNotNull(reply);
		Assert.assertEquals(reply.getBookList().get(0).getId(), Integer.valueOf(2));
		Assert.assertEquals(reply.getId(), Integer.valueOf(2));
	}

	@Test
	public void returnBook_success() throws Exception {
		User reply = new User();
		reply = libraryServiceImpl.borrowCopyOfBook(3, 3);
		reply = libraryServiceImpl.returnBook(3, 3);
		Assert.assertNotNull(reply);
		Assert.assertEquals(reply.getId(), Integer.valueOf(3));
	}

	@Test
	public void returnBook_failure() throws Exception {
		Object reply = new Object();
		try {
			reply = libraryServiceImpl.returnBook(3, 4);
		} catch (Exception e) {
			reply = e.getMessage();
		}
		Assert.assertNotNull(reply);
		Assert.assertEquals(reply, "The user does not exist ");
	}

	@Test
	public void validateParama_expectedTrue() {
		boolean reply;
		reply = libraryServiceImpl.validateParama(1, 1);
		Assert.assertNotNull(reply);
		Assert.assertEquals(reply, true);
	}

	@Test
	public void validateParama_expectedFalse() {
		boolean reply;
		reply = libraryServiceImpl.validateParama(5, 1);
		Assert.assertNotNull(reply);
		Assert.assertEquals(reply, false);
	}
}
